package com.example.belladonna

import android.app.DatePickerDialog
import android.app.Dialog
import android.app.DialogFragment
import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AlertDialog
import java.util.*
import kotlin.collections.ArrayList

lateinit var listItem : ArrayList<Clist>
lateinit var adp: CustomListAdapter
lateinit var listView : ListView
lateinit var dateFilterButton: Button
lateinit var search : SearchView
lateinit var backSrchBtn : Button
lateinit var dglId : String
lateinit var DelId : String
lateinit var itemText : TextView


class searchActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)
        supportActionBar?.hide()

        search = findViewById(R.id.searchBar)
        backSrchBtn = findViewById(R.id.backSrchBTN)

        itemText = findViewById(R.id.itemText)

        listView = findViewById(R.id.listView)

        listItem = ArrayList()
        adp = CustomListAdapter(this, listItem)
        listView.adapter = adp

        dateFilterButton = findViewById(R.id.selectDate)

        search.setOnQueryTextListener(object : SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                adp.filter.filter(newText)
                return false
            }
        })

            viewData()

        dateFilterButton.setOnClickListener {
            val fragment : DialogFragment = CustomDatePickerFragment()
            fragment.show(fragmentManager,"Date Picker")
        }

        backSrchBtn.setOnClickListener {
            val i = Intent(this, MainActivity :: class.java)
            startActivity(i)
        }

        listView.setOnItemLongClickListener { parent, view, position, id ->
            DelId = listItem[position].CLId
            showAlert()
            return@setOnItemLongClickListener true
        }

        listView.setOnItemClickListener { parent, view, position, id ->
            dglId = listItem[position].CLId
            Toast.makeText(applicationContext, "${listView}", Toast.LENGTH_SHORT).show()
            customDialog()
        }
    }


    private fun viewData() {
        val data = databaseHelper.readData()

        if (data != null && data.count > 0) {
            while (data.moveToNext()) {
                itemText.text = listItem.toString()
                listItem.add(Clist("${data.getString(1)}","${data.getString(5)}","${data.getString(0)}")).toString()
            }
        }else {
            Toast.makeText(applicationContext, "No Data", Toast.LENGTH_SHORT).show()
        }
      }

    private fun showDataByDate() {
        val data = databaseHelper.showDataByDate()

        if (data != null && data.count > 0) {
            while (data.moveToNext()) {
                listItem.add(Clist("${data.getString(1)}","${data.getString(5)}","${data.getString(0)}"))
            }
        }else {
            Toast.makeText(applicationContext, "No Data", Toast.LENGTH_SHORT).show()
        }
    }

    private fun deleteDataFunction() {
        val strId = DelId
        val result : Boolean = databaseHelper.deleteData(strId)
        when{
            result -> Toast.makeText(applicationContext, "Data Deleted Successfully...", Toast.LENGTH_SHORT).show()
            else -> Toast.makeText(applicationContext, "Failed To Delete Data...", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAlert(){
        val alertDialogBuilder = AlertDialog.Builder(this)
        alertDialogBuilder.setTitle("Conferma..")
        alertDialogBuilder.setIcon(R.drawable.ic_delete)
        alertDialogBuilder.setMessage("confermi di voler procedere?")
        alertDialogBuilder.setCancelable(false)
        alertDialogBuilder.setPositiveButton("Si"){ _, _ ->
            deleteDataFunction()
            finish()
            startActivity(intent)
        }
        alertDialogBuilder.setNegativeButton("No"){ _, _->}
        alertDialogBuilder.setNeutralButton("Cancel"){ _, _->}

        val alertDialog = alertDialogBuilder.create()
        alertDialog.show()
    }

    private fun customDialog(){
        val inflater = layoutInflater
        val inflateView = inflater.inflate(R.layout.custom_dialog, null)
        val data = databaseHelper.showData()
        val stringBuffer = StringBuffer()
        val dlgText = inflateView.findViewById<TextView>(R.id.dialogText)

        while (data.moveToNext()){
            stringBuffer.append("- ID: ${data.getString(0)}\n\n")
            stringBuffer.append("- Nome e Cognome:\n ${data.getString(1)}\n\n")
            stringBuffer.append("- Numero Telefono:\n ${data.getString(2)}\n\n")
            stringBuffer.append("- Numero Adulti / Bambini:\n ${data.getString(3)} / ${data.getString(4)}\n\n")
            stringBuffer.append("- Data:\n ${data.getString(5)}")
        }

        dlgText.text = stringBuffer.toString()

        val alertDialog = AlertDialog.Builder(this)
        alertDialog.setTitle("I DATI DI QUESTO CLIENTE:")
        alertDialog.setView(inflateView)
        alertDialog.setIcon(android.R.drawable.ic_menu_sort_by_size)
        alertDialog.setCancelable(false)

        alertDialog.setPositiveButton("Ok"){ _, _ -> }
        val dialog = alertDialog.create()
        dialog.show()
    }

//    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
//
//        val inflater = menuInflater
//        inflater.inflate(R.menu.options_menu, menu)
//        val menuItem = menu!!.findItem(R.id.search)
//        var viewSearch = MenuItemCompat.getActionView(menuItem) as SearchView
//        viewSearch.setOnQueryTextListener(object : SearchView.OnQueryTextListener{
//            override fun onQueryTextSubmit(query: String?): Boolean {
//                viewSearch.clearFocus()
//                    adp.filter.filter(query)
//                    Toast.makeText(applicationContext, "Match Not Found", Toast.LENGTH_SHORT).show()
//                return false
//            }
//
//            override fun onQueryTextChange(newText: String?): Boolean {
//                TODO("Not yet implemented")
//            }
//
//        })
//
//
//        return super.onCreateOptionsMenu(menu)
//    }
    class CustomDatePickerFragment : DialogFragment(),DatePickerDialog.OnDateSetListener{
        override fun onCreateDialog(savedInstanceState: Bundle?) : Dialog{
            super.onCreate(savedInstanceState)
            val calendar : Calendar = Calendar.getInstance()

            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH)
            val day = calendar.get(Calendar.DAY_OF_MONTH)

            val datePickerDialog = DatePickerDialog(activity,android.app.AlertDialog.THEME_HOLO_LIGHT,this,year,month,day)

            val textView = TextView(activity)

            val layoutParams = RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT)

            textView.layoutParams = layoutParams
            textView.setPadding(20,20,20,20)
            textView.gravity = Gravity.CENTER
            textView.setTextSize(TypedValue.COMPLEX_UNIT_DIP,25f)
            textView.text = "Scegli Data.."
            textView.setTextColor(Color.parseColor("#ffffff"))
            textView.setBackgroundColor(Color.parseColor("#608BC506"))

            datePickerDialog.setCustomTitle(textView)

            return datePickerDialog

        }

        override fun onDateSet(view: DatePicker?, year: Int, month: Int, dayOfMonth: Int) {
            val realMonth = month + 1
            search.setQuery("$dayOfMonth/$realMonth/$year", false)
        }

    }

}
