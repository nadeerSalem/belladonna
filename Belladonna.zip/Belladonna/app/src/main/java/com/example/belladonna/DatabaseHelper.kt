package com.example.belladonna

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.provider.BaseColumns
import android.provider.BaseColumns._ID
import com.example.belladonna.DatabaseContainer.BookingTable.Companion.BAMBINI_COLUMN
import com.example.belladonna.DatabaseContainer.BookingTable.Companion.DATE_COLUMN
import com.example.belladonna.DatabaseContainer.BookingTable.Companion.NAME_LASTNAME_COLUMN
import com.example.belladonna.DatabaseContainer.BookingTable.Companion.PEOPLENUM_COLUMN
import com.example.belladonna.DatabaseContainer.BookingTable.Companion.PHONENUMBER_COLUMN
import com.example.belladonna.DatabaseContainer.BookingTable.Companion.TABLE_NAME

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {
    override fun onCreate(db: SQLiteDatabase?) {

        val bookingDataTable = "CREATE TABLE " +
                TABLE_NAME + " ( " +
                BaseColumns._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                NAME_LASTNAME_COLUMN + " TEXT," +
                PHONENUMBER_COLUMN + " TEXT," +
                PEOPLENUM_COLUMN + " TEXT," +
                BAMBINI_COLUMN + " TEXT," +
                DATE_COLUMN + " TEXT" + ")"


        db!!.execSQL(bookingDataTable)

    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
    }

    fun insertData (name : String, phoneNumber : String, peopleNumber : String, bambiniNumber : String,date : String): Boolean {
        val db : SQLiteDatabase = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(NAME_LASTNAME_COLUMN, name)
        contentValues.put(PHONENUMBER_COLUMN, phoneNumber)
        contentValues.put(PEOPLENUM_COLUMN, peopleNumber)
        contentValues.put(BAMBINI_COLUMN, bambiniNumber)
        contentValues.put(DATE_COLUMN, date)
        val dataInsert = db.insert(TABLE_NAME, null, contentValues)
        db.close()

        return !dataInsert.equals(-1)
    }

    fun readData(): Cursor {
        val db: SQLiteDatabase = this.writableDatabase
        return db.rawQuery("SELECT * FROM $TABLE_NAME", null)
    }

    fun deleteData( id:String ): Boolean {
        val db: SQLiteDatabase = this.writableDatabase
        val delete = db.delete(TABLE_NAME, "$_ID=?", arrayOf(id))
        return delete != -1
    }

    fun getProfilesCount(): Int {
        val countQuery = "SELECT * FROM $TABLE_NAME"
        val db = this.readableDatabase
        val cursor = db.rawQuery(countQuery, null)
        val count = cursor.count
        cursor.close()
        return count
    }

    fun showData() : Cursor{
        val db: SQLiteDatabase = this.writableDatabase
        return db.rawQuery("SELECT * FROM $TABLE_NAME WHERE $_ID = $dglId", null)
    }

    fun showDataByDate() : Cursor{
        val db: SQLiteDatabase = this.writableDatabase
        return db.rawQuery("SELECT * FROM $TABLE_NAME WHERE $DATE_COLUMN = 18/5/2021",null)
    }

    companion object{
        private const val DATABASE_NAME = "Book.db"
        private const val DATABASE_VERSION = 1
    }

}