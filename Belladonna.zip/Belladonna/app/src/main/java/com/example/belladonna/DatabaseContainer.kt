package com.example.belladonna

import android.database.Cursor
import android.database.sqlite.SQLiteQueryBuilder
import android.provider.BaseColumns


object DatabaseContainer{

    class BookingTable : BaseColumns {
        companion object{
            const val TABLE_NAME = "Person_table"
            const val NAME_LASTNAME_COLUMN = "NAME"
            const val PHONENUMBER_COLUMN = "PHONE_NUMBER"
            const val PEOPLENUM_COLUMN = "PEOPLE_NUMBER"
            const val BAMBINI_COLUMN = "BAMBINI_NUMBER"
            const val DATE_COLUMN = "DATE"
        }
    }
}
