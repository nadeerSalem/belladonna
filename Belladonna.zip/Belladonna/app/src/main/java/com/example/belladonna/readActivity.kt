package com.example.belladonna


import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity


lateinit var backBtn : Button
lateinit var searchBtn : Button
lateinit var dataCountTxt : TextView
lateinit var syncBtn : Button
lateinit var testText : TextView
lateinit var readListView : ListView
lateinit var readListItem : ArrayList<String>
lateinit var readAdapter : ArrayAdapter<String>
lateinit var dataId : String


class readActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_read)
        supportActionBar?.hide()


        databaseHelper = DatabaseHelper(this)
        backBtn = findViewById(R.id.backBtn)
        readListView = findViewById(R.id.readListView)
        readListItem = ArrayList()
        readAdapter = ArrayAdapter(this,android.R.layout.simple_list_item_1, readListItem)
        readListView.adapter = readAdapter
        searchBtn = findViewById(R.id.searchBTN)
        dataCountTxt = findViewById(R.id.dbCount)
        syncBtn = findViewById(R.id.syncBtn)
        testText = findViewById(R.id.textTest)

        readListView.setOnItemClickListener { parent, view, position, id ->
            val numbers : String = readListView.getItemAtPosition(position).toString()
            val ar: Array<String> = numbers.split("\n").toTypedArray()
            dataId = ar[0]
            Toast.makeText(applicationContext, "$dataId", Toast.LENGTH_SHORT).show()
        }

//        syncBtn.text = "I DATI"

        backBtn.setOnClickListener {
            val i = Intent(this, MainActivity :: class.java)
            startActivity(i)
        }

        searchBtn.setOnClickListener {
            val i = Intent(this, searchActivity :: class.java)
            startActivity(i)
        }

        readData()
        
//        syncBtn.setOnClickListener {
//            syncBtn.text = "SYNC"
//            dataCountTxt.visibility = syncBtn.visibility
//            readData()
//            val profile_counts: Int = databaseHelper.getProfilesCount()
//            dataCountTxt.text = profile_counts.toString()
//        }

    }

    private fun readData() {

        val data = databaseHelper.readData()

        if (data != null && data.count > 0) {
            while (data.moveToNext()) {
                readListItem.add("ID: ${data.getString(0)} \n" +
                        "Nome e Cognome: ${data.getString(1)} \n" +
                        "Numero Telefono: ${data.getString(2)} \n" +
                        "Numero Adulti / Bambini: ${data.getString(3)} / ${data.getString(4)}\n" +
                        "Data: ${data.getString(5)} \n")
            }
        }else {
            Toast.makeText(applicationContext, "No Data", Toast.LENGTH_SHORT).show()
        }
    }

//   private fun showData(){
//        val data = databaseHelper.showData()
//        val stringBuffer = StringBuffer()
//
//       while(data.moveToNext()){
//           stringBuffer.append("NAME: ${data.getString(1)}")
//       }
//       testText.text = stringBuffer.toString()
//    }
}