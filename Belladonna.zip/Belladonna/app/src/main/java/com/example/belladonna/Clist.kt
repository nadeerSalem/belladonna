package com.example.belladonna

class Clist(
    var CLName: String,
    var CLDate: String,
    var CLId: String) {
}