package com.example.belladonna

import android.app.Activity
import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.SearchView
import android.widget.TextView

class CustomListAdapter(private val getContext : Context, private val customListItem : ArrayList<Clist>):
ArrayAdapter<Clist>(getContext, 0, customListItem){

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {

        var listLayout = convertView
        val holder : ViewHolder

        if (listLayout == null){
            val inflateList = (getContext as Activity).layoutInflater

            listLayout = inflateList!!.inflate(R.layout.custom_list, parent, false)
            holder = ViewHolder()
            holder.textOne = listLayout!!.findViewById(R.id.listName)
            holder.textTwo = listLayout!!.findViewById(R.id.listDate)
            holder.textTree = listLayout!!.findViewById(R.id.listId)

            listLayout.tag = holder
        }else {
            holder = listLayout.tag as ViewHolder
        }

        val ClistItem = customListItem[position]

        holder.textOne!!.text = ClistItem.CLName
        holder.textTwo!!.text = ClistItem.CLDate
        holder.textTree!!.text = ClistItem.CLId

        return listLayout
    }

}

    class ViewHolder(){
        internal var textOne : TextView? = null
        internal var textTwo : TextView? = null
        internal var textTree : TextView? = null
    }