package com.example.belladonna

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import java.util.*
import kotlin.properties.Delegates

lateinit var name : EditText
lateinit var phoneNumber : EditText
lateinit var insertBtn : Button
lateinit var readBtn : Button
lateinit var dateTXT : TextView
lateinit var peopleNumber : EditText
lateinit var bambiniNumber : EditText
lateinit var databaseHelper: DatabaseHelper

class MainActivity : AppCompatActivity() {
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportActionBar?.hide()

        val dateTxt : TextView = findViewById(R.id.dateTxt)

        name = findViewById(R.id.nameEdtTxt)
        phoneNumber = findViewById(R.id.NumEdtTxt)
        insertBtn = findViewById(R.id.insertBTN)
        readBtn = findViewById(R.id.readtBTN)
        peopleNumber = findViewById(R.id.adultiNum)
        bambiniNumber = findViewById(R.id.bambiniNum)
        databaseHelper = DatabaseHelper(this)
        dateTXT = dateTxt


        val date = findViewById<DatePicker>(R.id.pick_date) as DatePicker
        val calendar : Calendar = Calendar.getInstance()
        date.minDate = System.currentTimeMillis() - 1000

        date.init(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)) { view, year, monthOfYear, dayOfMonth ->
            dateTxt.text = "${date.dayOfMonth}" + "/" + "${date.month + 1}" + "/" + "${date.year}"
        }

        insertBtn.setOnClickListener {
            if (name.text.isNotEmpty() && phoneNumber.text.isNotEmpty() && peopleNumber.text.isNotEmpty()) {
                showAlert()
            }
        }

        readBtn.setOnClickListener {
            val i = Intent(this,searchActivity :: class.java)
            startActivity(i)
        }

    }

    private fun insertFunction(){

        val strName = name.text.toString()
        val strPhoneNum = phoneNumber.text.toString()
        val strPeopleNum = peopleNumber.text.toString()
        val strBambiniNumber = bambiniNumber.text.toString()
        val strDate = dateTXT.text.toString()


        if (name.text.isNotEmpty() && phoneNumber.text.isNotEmpty() && peopleNumber.text.isNotEmpty()) {
        val result : Boolean = databaseHelper.insertData(strName,strPhoneNum,strPeopleNum, strBambiniNumber, strDate)
        when{
            result -> Toast.makeText(applicationContext,"Data inserted successfully..",Toast.LENGTH_SHORT).show()
            else -> Toast.makeText(applicationContext,"Failed to insert data",Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showAlert(){
        val alertDialogBuilder = AlertDialog.Builder(this)
        alertDialogBuilder.setTitle("Conferma..")
        alertDialogBuilder.setIcon(R.mipmap.ic_launcher)
        alertDialogBuilder.setMessage("Confermi di voler riservare?")
        alertDialogBuilder.setCancelable(false)
        alertDialogBuilder.setPositiveButton("Si"){ _, _ ->
            insertFunction()
            name.text.clear()
            phoneNumber.text.clear()
            peopleNumber.text.clear()
            bambiniNumber.text.clear()
            dateTXT.text = "DD/MM/YYYY"
        }
        alertDialogBuilder.setNegativeButton("No"){ _, _->}
        alertDialogBuilder.setNeutralButton("Cancel"){ _, _->}

        val alertDialog = alertDialogBuilder.create()
        alertDialog.show()
    }
}
